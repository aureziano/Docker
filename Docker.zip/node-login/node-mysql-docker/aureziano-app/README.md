# Node.js Rest APIs with Express, Sequelize & MySQL example


## Project setup
```
npm install
```

### Run
```
node server.js
```
